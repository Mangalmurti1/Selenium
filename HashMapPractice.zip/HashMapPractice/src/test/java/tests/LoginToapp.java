package tests;

import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Data.DataReader;

public class LoginToapp extends DataReader{

	@Test (dataProvider="getData")
	public void Login(HashMap<String,String>input) throws InterruptedException
	{
		initializeDriver();

		driver.get("https://rahulshettyacademy.com/client");
		driver.findElement(By.id("userEmail")).sendKeys(input.get("uname"));
		driver.findElement(By.id("userPassword")).sendKeys(input.get("pass"));
		driver.findElement(By.id("login")).click();
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(5));
		WebElement webelement=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@aria-label='Login Successfully']")));
		System.out.println("Login msg :"+webelement.getText());
		
		Assert.assertEquals(webelement.getText(),"Login Successfully","Congratualtions...");
		
	}
	
	@DataProvider
	public Object[][] getData() throws IOException
	{
		List<HashMap<Object,Object>>data=getJsonData(System.getProperty("user.dir")+"\\src\\main\\java\\Data\\dataReadMe.json");
		return new Object [][] {{data.get(0)},{data.get(1)}};
		
	}
}

