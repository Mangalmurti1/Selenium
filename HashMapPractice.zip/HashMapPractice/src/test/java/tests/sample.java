package tests;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class sample {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
        WebDriver driver= new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/client");
		driver.manage().window().maximize();
		
		driver.findElement(By.id("userEmail")).sendKeys("onkarsapkal123@gmail.com");
		driver.findElement(By.id("userPassword")).sendKeys("Onkarsapkal@123");
		driver.findElement(By.id("login")).click();
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(5));
		WebElement webelement=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@aria-label='Login Successfully']")));
		System.out.println("Login msg :"+webelement.getText());
		//WebElement mesg= driver.findElement(By.xpath("//div[text()=' Incorrect email or password. ']"));
		
		//WebElement webelement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space(text())='Incorrect email or password.']")));
		//WebElement mesg= driver.findElement(By.cssSelector(".toast-success"));
		
		//System.out.println(message);
		////div[@aria-label='Incorrect email or password.']
		
		
		
//WebDriver driver= new ChromeDriver();
//		
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
//		driver.get("https://rahulshettyacademy.com/client/");
//		driver.manage().window().maximize();
//		
//		driver.findElement(By.id("useremail")).sendKeys("standarduser@hfdd.com");
//		//input[@id='userEmail']
//		//Thread.sleep(1000);
//		
//		driver.findElement(By.id("userPassword")).sendKeys("standarduseasa");
//		//input[@id='userPassword']
//		
//		//input[@id='login']
//		
//		driver.findElement(By.id("login")).click();
//		
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		//WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='ng-tns-c4-0 ng-star-inserted ng-trigger ng-trigger-flyInOut ngx-toastr toast-error']")));
//		
//		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Incorrect email or password. ']")));
//		System.out.println("Text is:  "+element.getText());
//		
		
	}

}
