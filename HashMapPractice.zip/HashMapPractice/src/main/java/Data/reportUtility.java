package Data;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class reportUtility {

	public static ExtentReports extentReport()
	{
		ExtentSparkReporter reporter= new ExtentSparkReporter(new String(System.getProperty("user.dir")+"//Reports//ExtentReport.html"));
		reporter.config().setDocumentTitle("LoginCase");
		reporter.config().setReportName("LoginActivities");
		
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Developer", "Mahesh R");
		extent.setSystemInfo("Tester","Madhuri C");
		return extent;
	}
}
