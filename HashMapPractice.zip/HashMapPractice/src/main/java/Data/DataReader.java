package Data;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DataReader {

	public WebDriver driver;
	public void initializeDriver()
	{
		 driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		//return driver;
		}
	
	public List<HashMap<Object, Object>> getJsonData(String filePath) throws IOException
	{
		//converted json file to string 
		//String filePath= System.getProperty("user.dir")+"\\src\\main\\java\\Data\\dataReadMe.json";
		String jsonconvertToString= FileUtils.readFileToString(new File (filePath),StandardCharsets.UTF_8);
		
		//converted string to hashmap
		ObjectMapper mapper= new ObjectMapper();
		List<HashMap<Object,Object>>data=mapper.readValue(jsonconvertToString, new TypeReference <List<HashMap<Object,Object>>>(){});
		return data;
		
	}
	
	public String getScreenshot(String testcaseName) throws IOException
	{
		File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src,new File(System.getProperty("user.dir")+"//ScreenSHOTS//"+testcaseName+".png"));
		return System.getProperty("user.dir")+"//ScreenSHOTS//"+testcaseName+".png";
		
	}
	
	
	
}
